<template>
  <div style="padding:30px;">

    <!-- <el-alert :closable="false" title="menu 2" /> -->
    <editor />
  </div>
</template>
<script>
import Editor from  "@/components/Editor/index"
export default {
  components:{Editor},
  data(){
    return {

    }
  }
}
</script>
