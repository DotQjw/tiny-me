<template>
  <div>
    <editor
      id="tinymce"
      v-model="myValue"
      :init="init"
      :disabled="disabled"
    >
    </editor>
  </div>
</template>

<script>
import tinymce from "tinymce";
import Editor from "@tinymce/tinymce-vue";
import "tinymce/themes/silver/theme";
// import "tinymce/themes/silver";
// import "tinymce/plugins/paste";
import "tinymce/plugins/image";
import "tinymce/plugins/link";
import "tinymce/plugins/code";
import "tinymce/plugins/table";
import "tinymce/plugins/lists";
import "tinymce/plugins/wordcount";
// import "tinymce/themes/mobile/theme";
// import "tinymce/plugins/colorpicker";
// import "tinymce/plugins/textcolor";
import "tinymce/icons/default";
import "tinymce/models/dom";
export default {
  //powerpaste插件为tinymce的收费插件，下载之后放入static/tinymce/plugins文件夹//该插件作用为复制word文档时批量上传图片，不需要的可以不要
  components: {
    Editor,
  },
  props: {
    //传入一个value，使组件支持v-model绑定
    value: {
      type: String,
      default: "",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    plugins: {
      type: [String, Array],
      default: "",
      // "lists image table wordcount  code", //插件
    },
    toolbar: {
      type: [String, Array],
      //菜单
      default: "undo redo",
      // "undo redo | formatselect | bold italic forecolor backcolor | alignleft aligncenter alignright  | bullist numlist outdent indent |     | removeformat",
    },
  },
  watch: {
    myValue(n, o) {
      console.log(n, o);
      if (n.includes("color")) {
        console.log("in");
        n = n.replace(/color/g, "");
        // this.editorVm.setContent(n)
        this.setData(n);

        console.log("n", n);
      }
    },
  },
  data() {
    var that = this;
    return {
      myValue: "",
      editorVm: "",
      //初始化配置
      init: {
        language_url: "tinymce/langs/zh_CN.js", //如果语言包不存在，指定一个语言包路径
        language: "zh_CN", //语言
        skin_url: "tinymce/skins/ui/oxide",
        content_css: "tinymce/skins/content/default/content.css",
        height: "500px",
        selector: "textarea", // change this value according to your HTML
        plugins: this.plugins, //插件
        //以下为powerpaste插件配置
        convert_urls: false,
        // external_plugins: {
        //   powerpaste: `/tinymce/plugins/powerpaste/plugin.min.js`, // 注意这里路径一定要写对！！！一定要写对  然后在puligins里添加
        // },
        end_container_on_empty_block: true,
        powerpaste_word_import: "propmt", // 参数可以是propmt, merge, clear，效果自行切换对比
        powerpaste_html_import: "propmt", // propmt, merge, clear
        powerpaste_allow_local_images: true,
        paste_data_images: true,
        //以上为powerpaste插件配置
        toolbar: this.toolbar, //工具栏
        branding: false, //技术支持(Powered by Tiny || 由Tiny驱动)
        menubar: true, //菜单栏
        menu: {
          file: { title: "文件", items: "newdocument" },
          edit: {
            title: "编辑",
            items: "undo redo | cut copy paste pastetext | selectall",
          },
          insert: { title: "插入", items: "link media | template hr" },
          view: { title: "查看", items: "visualaid" },
          format: {title: '格式', items: 'bold italic underline strikethrough superscript subscript | formats | removeformat'},
          table: {
            title: "表格",
            items: "inserttable tableprops deletetable | cell row column",
          },
          tools: { title: "工具", items: "spellchecker code" },
        },
        theme: "silver", //主题
        //此处为图片上传处理函数，这个直接用了base64的图片形式上传图片，
        //如需ajax上传可参考https://www.tiny.cloud/docs/configure/file-image-upload/#images_upload_handler
        images_upload_url: "www.baidu.com",
        automatic_uploads: false,
        images_upload_handler: (blobInfo, success, failure) => {
          console.log({ blobInfo, success, failure });
          // console.log(blobInfo, success, failure);
        },
        setup: function (editor) {
          console.log("ID为: " + editor.id + " 的编辑器即将初始化.");
        },
        init_instance_callback: function (editor) {
          console.log("ID为: " + editor.id + " 的编辑器已初始化完成.", editor);
          that.editorVm = editor;
          editor.setContent("这里什么都没有");
          this.hasInit = true;
          editor.on("NodeChange Change KeyUp SetContent", () => {
            this.hasChange = true;
            // this.$emit("input", editor.getContent());
          });
        },
      },
    };
  },
  mounted() {
    // tinymce.init({});
  },
  methods: {
    setData(data) {
      console.log("setData", data);
      this.editorVm.setContent(data);
    }
  },
};
</script>
